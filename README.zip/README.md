
<p align="center">
  <img src="https://i.imgur.com/xgIAdQt.png" width="350" />
  <img src="https://i.imgur.com/LT3DAUl.png" width="350" />
</p>

# RUBBUR_WORLD

Rubbur world is a game about a ball, a red ball, a red ball named RUBBUR\
and RUBBUR bounce so hard in his world, the RUBBUR WORLD! boss fight in a new release soon !


## Release

Game is available online on Itch.io at https://aslayeron.itch.io/rubbur-world

