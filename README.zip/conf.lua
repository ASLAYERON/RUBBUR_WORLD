
function love.conf(t)
	t.console = true
	t.window.title = "RUBBUR WORLD"
	t.window.width = 700
	t.window.height = 500
end